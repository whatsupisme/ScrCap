#define id_curFinger 1001
//#define id_btnTest_Off 1001
//#define id_btnTest_On 1002
