although the source is available
the app cannot be build from the source for now.
maybe in the future.

the binaries for windows 64 bit available.


this project was started many years ago from a vb6 project found on planet source code.
since than it was completely modified.
