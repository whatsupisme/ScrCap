this app was loaded from planet source code.
it was little changed - converted to CodeBase and reArranged.

it can be build as a standAlone and as a part of ScrCap.

for now it cannot be build from source.

maybe in the future.